import {combineReducers} from 'redux'

import clickReducer from "./reducers/clickReducer";

export default combineReducers({
    clickReducer,
})