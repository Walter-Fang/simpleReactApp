export const isPlaying = (payload) =>{
    return {
        type:'isPlaying',
        payload
    }
}