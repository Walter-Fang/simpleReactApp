
import { Modal } from 'antd';

function CovidModal(){
    // const [modal, contextHolder] = Modal.useModal();
    return (
        <>
            <h1>hello</h1>

        </>
    )
}

export default CovidModal