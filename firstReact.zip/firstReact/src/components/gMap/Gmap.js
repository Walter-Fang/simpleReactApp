

import GoogleMap from './GoogleMap'



export default function Gmap(){

    return(
        <div className='Gmap'>

            <GoogleMap />
        </div>
    )
}