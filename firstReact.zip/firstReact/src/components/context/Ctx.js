import {createContext} from 'react'

export const Ctx = createContext(null)

