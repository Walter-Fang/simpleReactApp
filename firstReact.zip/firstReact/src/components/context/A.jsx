import B from "./B";

function A(){
    return (
        <>
            <h1>This is A component</h1>
            <B />
        </>
    )
}
export default A