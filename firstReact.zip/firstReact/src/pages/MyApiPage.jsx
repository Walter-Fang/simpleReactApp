import MyApi from "../components/myApi/MyApi";

function MyApiPage(props){
    return (
        <>
            <MyApi />
        </>
    )
}

export default MyApiPage