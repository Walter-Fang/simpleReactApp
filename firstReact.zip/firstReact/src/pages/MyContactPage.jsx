import MyCv from "../components/myCV/MyCv";

function MyContactPage(props){
    return (
        <>
            <MyCv />
        </>
    )
}

export default MyContactPage