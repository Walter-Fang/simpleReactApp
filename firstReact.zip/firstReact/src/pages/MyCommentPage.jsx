import MyComment from "../components/myComment/MyComment";

function MyCommentPage(props){
    return (
        <>
            <MyComment />
        </>
    )
}

export default MyCommentPage